function addLike(){
    var num = document.getElementById('num');
    var number = num.innerHTML;
    number++;
    num.innerHTML = number;
}

function addLike2(){
    var num = document.getElementById('num2');
    var number = num.innerHTML;
    number++;
    num.innerHTML = number;
}

function addLike3(){
    var num = document.getElementById('num3');
    var number = num.innerHTML;
    number++;
    num.innerHTML = number;
}