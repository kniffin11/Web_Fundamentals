console.log("page loaded...");

var x = document.getElementById("myVideo");

function playVid(element){
    x.play();
}

function pauseVid(element){
    x.pause();
}